function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min))
}
function calculaTransaccion(primerNumero, segundoNumero, operacion) {
    comisionTransaccion = segundoNumero * comision;
    switch (operacion) {
        case "+":
            return primerNumero + segundoNumero;
        case "-":
            return primerNumero - segundoNumero;
        default:
            return 0;
    }
}

const cotizacionETH = randomIntFromInterval(1000, 50000)
const cotizacionBTC = randomIntFromInterval(1000, 50000)

let numeroDeTransacciones = parseInt(prompt("Bienvenido a CompraCryptosYa.com. Ingrese el numero de transacciones a realizar:"));
let tipoTransaccion = "";
let cantidadETH = 10;
let cantidadBTC = 5;
let tipoCrypto = "";
let cantidadIngresada = 0;
const comision = 0.05
let comisionTransaccion = 0
let operacion = ""
let cantidadBilletera = 700000;

for(let i = 0; i < numeroDeTransacciones; i++){
    tipoTransaccion = prompt(`Qué tipo de transacción quiere realizar?.\nSeleccione la opción del menú:\nCompra: 1\nVenta: 2 \nIngresar dinero: 3 \nRetirar dinero: 4`);
    switch(tipoTransaccion){
        case "1":
            operacion = "+"
                tipoCrypto = prompt(`Qué Crypto quiere comprar?.\nLas siguientes son opciones válidas con su cotización:\nETH: ${cotizacionETH}\nBTC: ${cotizacionBTC} \nUsted dispone de la siguiente cantidad de Cryptos: \nETH: ${cantidadETH} \nBTC: ${cantidadBTC}`);
                cantidadIngresada = parseInt(prompt(`Cuántas Crypto ${tipoCrypto.toUpperCase()} desea comprar? Usted dispone de ${cantidadBilletera} pesos`));
                if(tipoCrypto.toUpperCase() === "ETH" && cantidadBilletera >= (cantidadIngresada * cotizacionETH)){
                    cantidadETH = calculaTransaccion(cantidadETH, cantidadIngresada, operacion);
                    cantidadBilletera = calculaTransaccion(cantidadBilletera, (cantidadIngresada * cotizacionETH), "-") - comisionTransaccion;
                    alert(`La compra fue realizada con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${cantidadETH} ${tipoCrypto.toUpperCase()} y ${cantidadBilletera} pesos en su saldo`);   
                }else if(tipoCrypto.toUpperCase() === "BTC" && cantidadBilletera >= (cantidadIngresada * cotizacionBTC)){
                    cantidadBTC = calculaTransaccion(cantidadBTC, cantidadIngresada, operacion);
                    cantidadBilletera = calculaTransaccion(cantidadBilletera, (cantidadIngresada * cotizacionBTC), "-") - comisionTransaccion;
                    alert(`La compra fue realizada con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${cantidadBTC} ${tipoCrypto.toUpperCase()} y ${cantidadBilletera} pesos en su saldo`);
                }else{
                    alert(`No se realizaron compras de Cryptos.`);
                }
            break;
        case "2":
            operacion = "-"
                tipoCrypto = prompt(`Qué Crypto quiere vender?.\nLas siguientes son opciones válidas con su cotización:\nETH: ${cotizacionETH}\nBTC: ${cotizacionBTC} \nUsted dispone de la siguiente cantidad de Cryptos: \nETH: ${cantidadETH} \nBTC: ${cantidadBTC}`);
                cantidadIngresada = parseInt(prompt(`Cuántas Crypto ${tipoCrypto.toUpperCase()} desea vender?`));
                if(tipoCrypto.toUpperCase() === "ETH" && cantidadETH >= cantidadIngresada){
                    cantidadETH = calculaTransaccion(cantidadETH, cantidadIngresada, operacion);
                    cantidadBilletera = calculaTransaccion(cantidadBilletera, (cantidadIngresada * cotizacionETH), "+") - comisionTransaccion;
                    alert(`La venta fue realizada con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${cantidadETH} ${tipoCrypto.toUpperCase()} y ${cantidadBilletera} pesos en su saldo`);
                }else if(tipoCrypto.toUpperCase() === "BTC" && cantidadBTC >= cantidadIngresada){
                    cantidadBTC = calculaTransaccion(cantidadBTC, cantidadIngresada, operacion);
                    cantidadBilletera = calculaTransaccion(cantidadBilletera, (cantidadIngresada * cotizacionBTC), "+") - comisionTransaccion;
                    alert(`La venta fue realizada con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${cantidadBTC} ${tipoCrypto.toUpperCase()} y ${cantidadBilletera} pesos en su saldo`);
                }else{
                    alert(`No tiene suficientes ${tipoCrypto} para vender.`);
                }
            break;
        case "3":
            operacion = "+"
                cantidadIngresada = parseInt(prompt(`Cuánto dinero desea ingresar?`))
                cantidadBilletera = calculaTransaccion(cantidadBilletera, cantidadIngresada, operacion) - comisionTransaccion;
                alert(`Dinero ingresado con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${cantidadBilletera} pesos en su billetera`);
            break;
        case "4":
            operacion = "-"
                cantidadIngresada = parseInt(prompt(`Cuánto dinero desea retirar?`))
                if(cantidadBilletera >= cantidadIngresada){
                    cantidadBilletera = calculaTransaccion(cantidadBilletera, cantidadIngresada, operacion) - comisionTransaccion;
                    alert(`Dinero retirado con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${cantidadBilletera} pesos en su billetera`);
                }else{
                    alert(`No tiene fondos suficientes. Ustede dispone de ${cantidadBilletera} pesos.`);
                }
            break;      
        default:
            alert("No seleccionó tipo de transacción.");
                break;
            }
}
alert("Todas las transacciones fueron ejecutadas. Muchas gracias por utilizar nuestro servicio")







