function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min))
}

const rndInt = randomIntFromInterval(1000, 50000)
const rndInt2 = randomIntFromInterval(1000, 50000)

let numeroDeTransacciones = parseInt(prompt("Ingrese el numero de transacciones a realizar:"));
let tipoTransaccion = "";
let cantidadETH = 10;
let cantidadBTC = 5;
let tipoCrypto = "";
let cantidadCrypto = 0;

for(let i = 0; i < numeroDeTransacciones; i++){
    tipoTransaccion = prompt(`Qué tipo de transacción quiere realizar?.\nSeleccione la opción del menú:\nCompra: 1\nVenta: 2`);
    if(tipoTransaccion === "1"){
        tipoCrypto = prompt(`Qué Crypto quiere comprar?.\nLas siguientes son opciones válidas con su cotización:\nETH: ${rndInt}\nBTC: ${rndInt2}`);
        cantidadCrypto = parseInt(prompt(`Cuántas Crypto ${tipoCrypto} desea comprar?`));
        if(tipoCrypto.toUpperCase() === "ETH"){
            cantidadETH = cantidadETH + cantidadCrypto;
            alert(`La compra fue realizada con éxito. usted dispone de ${cantidadETH} ${tipoCrypto}`);
        }else if(tipoCrypto.toUpperCase() === "BTC"){
            cantidadBTC = cantidadBTC + cantidadCrypto;
            alert(`La compra fue realizada con éxito. usted dispone de ${cantidadBTC} ${tipoCrypto}`);
        }else{
            alert(`No se realizaron compras de Cryptos.`);
        }
    }
    else if(tipoTransaccion === "2"){
        tipoCrypto = prompt(`Qué Crypto quiere vender?.\nLas siguientes son opciones válidas con su cotización:\nETH: ${rndInt}\nBTC: ${rndInt2}`);
        cantidadCrypto = parseInt(prompt(`Cuántas Crypto ${tipoCrypto} desea vender?`));
        if(tipoCrypto.toUpperCase() === "ETH" && cantidadETH >= cantidadCrypto){
            cantidadETH = cantidadETH - cantidadCrypto;
            alert(`La venta fue realizada con éxito. usted dispone de ${cantidadETH} ${tipoCrypto}`);
        }else if(tipoCrypto.toUpperCase() === "BTC" && cantidadBTC >= cantidadCrypto){
            cantidadBTC = cantidadBTC - cantidadCrypto;
            alert(`La venta fue realizada con éxito. usted dispone de ${cantidadBTC} ${tipoCrypto}`);
        }else{
            alert(`No tiene suficientes ${tipoCrypto} para vender.`);
        }
    }
    else{
        alert("No seleccionó tipo de transacción.");
    }
}
alert("Todas las transacciones fueron ejecutadas. Muchas gracias por utilizar nuestro servicio")







