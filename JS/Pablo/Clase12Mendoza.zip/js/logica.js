// Genera cotizaciones random para las Cryptos
function calculaTransaccion(primerNumero, segundoNumero, operacion) {
    comisionTransaccion = (segundoNumero * comision).toFixed(2);
    switch (operacion) {
        case "+":
            return primerNumero + segundoNumero;
        case "-":
            return primerNumero - segundoNumero;
        default:
            return 0;
    }
}
// Se guardan cálculos de compra, ventas de cryptos y movimientos de billetera por cada transaccion realizada.
function guardaCalculo() {
    arrayCantidadCryptos[idCrypto].cantidad = calculaTransaccion((JSON.parse(localStorage.getItem("arrayCantidadCryptos")))[idCrypto].cantidad, cantidadIngresada, operacion);
    cantidadBilletera = calculaTransaccion(cantidadBilletera, (cantidadIngresada * arrayCryptos[idCrypto].cotizacion), operacionBilletera) - comisionTransaccion;
    localStorage.setItem("arrayCantidadCryptos", JSON.stringify(arrayCantidadCryptos));
}
// Se renderiza página, de acuerdo a la lógica aplicada.
function renderizaPagina(resultado) {
    switch (resultado) {
        case "compraOK":
            contenedorCrypto.innerHTML = '';
            tituloTransaccion.innerHTML = `La compra fue realizada con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${arrayCantidadCryptos[idCrypto].cantidad} ${tipoCrypto.toUpperCase()} y ${cantidadBilletera.toFixed(2)} pesos en su saldo`;
            contenedorCrypto.append(tituloTransaccion, buttonTransaccion);
            buttonTransaccion.onclick = () => {decreceTransacciones()};
            break;
        case "compraNoOK":
            contenedorCrypto.innerHTML = '';
            tituloTransaccion.innerHTML = `No dispone de suficiente dinero en billetera.`;
            contenedorCrypto.append(tituloTransaccion, buttonTransaccion);
            buttonTransaccion.onclick = () => {bucleTransaccion()};
            break;
        case "ventaOK":
            contenedorCrypto.innerHTML = '';
            tituloTransaccion.innerHTML = `La venta fue realizada con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${arrayCantidadCryptos[idCrypto].cantidad} ${tipoCrypto.toUpperCase()} y ${cantidadBilletera.toFixed(2)} pesos en su saldo`;
            contenedorCrypto.append(tituloTransaccion, buttonTransaccion);
            buttonTransaccion.onclick = () => {decreceTransacciones()};
            break;
        case "ventaNoOK":
            contenedorCrypto.innerHTML = '';
            tituloTransaccion.innerHTML = `No tiene suficientes ${tipoCrypto} para vender.`;
            contenedorCrypto.append(tituloTransaccion, buttonTransaccion);
            buttonTransaccion.onclick = () => {bucleTransaccion()};
            break;
        case "ingresoBilleteraOK":
            contenedorCrypto.innerHTML = '';
            tituloTransaccion.innerHTML = `Dinero ingresado con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${cantidadBilletera.toFixed(2)} pesos en su billetera`;
            contenedorCrypto.append(tituloTransaccion, buttonTransaccion);
            buttonTransaccion.onclick = () => {decreceTransacciones()};
            break;
        case "retiroBilleteraOK":
            contenedorCrypto.innerHTML = '';
            tituloTransaccion.innerHTML = `Dinero retirado con éxito. La comisión por esta transacción fue de ${comisionTransaccion} pesos. Usted dispone de ${cantidadBilletera.toFixed(2)} pesos en su billetera`;
            contenedorCrypto.append(tituloTransaccion, buttonTransaccion);
            buttonTransaccion.onclick = () => {decreceTransacciones()};
            break;
        case "retiroBilleteraNoOK":
            contenedorCrypto.innerHTML = '';
            tituloTransaccion.innerHTML = `No tiene fondos suficientes. Ustede dispone de ${cantidadBilletera.toFixed(2)} pesos.`;
            contenedorCrypto.append(tituloTransaccion, buttonTransaccion);
            buttonTransaccion.onclick = () => {decreceTransacciones()};
            break;
        case "noTransaccion":
            contenedorCrypto.innerHTML = '';
            tituloTransaccion.innerHTML = `No seleccionó tipo de transacción.`;
            contenedorCrypto.append(tituloTransaccion, buttonTransaccion);
            buttonTransaccion.onclick = () => {bucleTransaccion()};
            break;
        case "transaccionesEjecutadas":
            tituloTransaccion.innerHTML = `Todas las transacciones fueron ejecutadas. Muchas gracias por utilizar nuestro servicio`;
            contenedorCrypto.innerHTML = '';
            buttonVolver.innerText = "Volver a empezar";
            buttonVolver.href = "../";
            contenedorCrypto.append(tituloTransaccion, buttonVolver);
    }
}
// Se descuentan transacciones a realizar
function decreceTransacciones() {
    numeroDeTransacciones--
    numeroDeTransacciones > 0 ? bucleTransaccion() : renderizaPagina("transaccionesEjecutadas");
}

if (!localStorage.getItem('arrayCantidadCryptos')) localStorage.setItem('arrayCantidadCryptos', JSON.stringify(arrayCantidadCryptos));

arrayCantidadCryptos = (JSON.parse(localStorage.getItem("arrayCantidadCryptos")));

//Mostramos página de cantidad de transacciones.
tituloTransaccion.innerHTML = "Ingrese el número de transacciones a realizar:"
contenedorCrypto.append(tituloTransaccion, inputTransaccion, buttonTransaccion);
buttonTransaccion.onclick = () => {
    numeroDeTransacciones = parseInt(inputTransaccion.value);
    inputTransaccion.value = '';
    bucleTransaccion();
}
//Solicitamos tipo de transacción para análisis.
function bucleTransaccion() {
    tituloTransaccion.innerHTML = "Qué tipo de transacción quiere realizar?.<br>Compra: 1<br>Venta: 2 <br>Ingresar dinero: 3 <br>Retirar dinero: 4";
    contenedorCrypto.append(tituloTransaccion, inputTransaccion, buttonTransaccion);
    buttonTransaccion.onclick = () => {
        tipoTransaccion = inputTransaccion.value
        inputTransaccion.value = '';
    //Analizamos el tipo de transacción ingresada y mostramos cryptos disponibles.
    switch(tipoTransaccion){
        case "1":
            operacion = "+"
            operacionBilletera = "-"
            tituloTransaccion.innerHTML = `<h1> Indique crypto y cantidad a comprar.</h1>
            <h2>A continuación cryptos disponibles y su cotización:</h2>
            <p>${arrayCryptos[0].crypto}  ${arrayCryptos[0].cotizacion}</p>
            <p>${arrayCryptos[1].crypto}  ${arrayCryptos[1].cotizacion}</p>`;
            contenedorCrypto.append(tituloTransaccion, inputTransaccion, inputCantidad, buttonTransaccion);
            buttonTransaccion.onclick = () => {
                tipoCrypto = inputTransaccion.value
                cantidadIngresada = parseInt(inputCantidad.value);
                inputTransaccion.value = '';
                inputCantidad.value = '';
                //Analizamos si para la crypto seleccionada tenemos suficiente dinero y mostramos opciones de acuerdo al análisis.
                if(tipoCrypto.toUpperCase() === "ETH" && cantidadBilletera >= (cantidadIngresada * arrayCryptos[0].cotizacion)){
                    idCrypto = 0;
                    guardaCalculo();
                    renderizaPagina("compraOK");
                }else if(tipoCrypto.toUpperCase() === "BTC" && cantidadBilletera >= (cantidadIngresada * arrayCryptos[1].cotizacion)){
                    idCrypto = 1;
                    guardaCalculo();
                    renderizaPagina("compraOK");
                }else{
                    renderizaPagina("compraNoOK");
                }
            }
            break;     
        case "2":
            operacion = "-"
            operacionBilletera = "+"
            tituloTransaccion.innerHTML = `<h1> Indique crypto y cantidad a vender.</h1>
            <h2>A continuación cryptos disponibles y su cotización:</h2>
            <p>${arrayCryptos[0].crypto}  ${arrayCryptos[0].cotizacion}</p>
            <p>${arrayCryptos[1].crypto}  ${arrayCryptos[1].cotizacion}</p>`;
            contenedorCrypto.append(tituloTransaccion, inputTransaccion, inputCantidad, buttonTransaccion);
            buttonTransaccion.onclick = () => {
                tipoCrypto = inputTransaccion.value
                cantidadIngresada = parseInt(inputCantidad.value);
                inputTransaccion.value = '';
                inputCantidad.value = '';
                //analizamos crypto sleccionada, si tenemos suficientes para vender y sumamos cantidad vendida a billetera.
                if(tipoCrypto.toUpperCase() === "ETH" && arrayCantidadCryptos[0].cantidad >= cantidadIngresada){
                    idCrypto = 0;
                    guardaCalculo();
                    renderizaPagina("ventaOK");
                }else if(tipoCrypto.toUpperCase() === "BTC" && arrayCantidadCryptos[1].cantidad >= cantidadIngresada){
                    idCrypto = 1
                    guardaCalculo();
                    renderizaPagina("ventaOK");
                }else{
                    renderizaPagina("ventaNoOK");
                }
            }
            break;
        case "3":
            operacionBilletera = "+"
            tituloTransaccion.innerHTML = `Cuánto dinero desea ingresar?`;
            contenedorCrypto.removeChild(inputTransaccion);
            contenedorCrypto.append(tituloTransaccion, inputCantidad, buttonTransaccion);
            buttonTransaccion.onclick = () => {
                cantidadIngresada = parseInt(inputCantidad.value);
                inputCantidad.value = '';
                cantidadBilletera = calculaTransaccion(cantidadBilletera, cantidadIngresada, operacionBilletera) - comisionTransaccion;
                renderizaPagina("ingresoBilleteraOK")
            }
            break;
        case "4":
            operacionBilletera = "-"
            tituloTransaccion.innerHTML = `Cuánto dinero desea retirar?`;
            contenedorCrypto.removeChild(inputTransaccion);
            contenedorCrypto.append(tituloTransaccion, inputCantidad, buttonTransaccion);
            buttonTransaccion.onclick = () => {
                cantidadIngresada = parseInt(inputCantidad.value);
                inputCantidad.value = '';
                if(cantidadBilletera >= cantidadIngresada){
                    cantidadBilletera = calculaTransaccion(cantidadBilletera, cantidadIngresada, operacionBilletera) - comisionTransaccion;
                    renderizaPagina("retiroBilleteraOK");
                }else{
                    renderizaPagina("retiroBilleteraNoOK");
                }
            }
            break;      
        default:
            renderizaPagina("noTransaccion");
            }
        }
    }





